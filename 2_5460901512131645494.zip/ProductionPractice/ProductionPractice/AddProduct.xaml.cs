﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProductionPractice
{
    /// <summary>
    /// Логика взаимодействия для AddProduct.xaml
    /// </summary>
    public partial class AddProduct : Window
    {
        AddInvoice ai;
        public AddProduct(AddInvoice ad)
        {
            InitializeComponent();
            ai = ad;
            prodName.ItemsSource = MainWindow.DB.Product.ToList();
        }

        private void Cancle_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (prodName.SelectedItem != null && Count.Text != "")
            {
                if (ai.isSale)
                { 
                    if (ai.SaleOld == null)
                    {
                        ai.SProd.Add(new SaleProduct
                        {
                            Product = (Product)prodName.SelectedItem,
                            Count = Convert.ToInt32(Count.Text),
                            Sale = ai.sale
                        });
                    }
                    else
                    {
                        ai.SProd.Add(new SaleProduct
                        {
                            Product = (Product)prodName.SelectedItem,
                            Count = Convert.ToInt32(Count.Text),
                            Sale = ai.SaleOld
                        });
                    }
                    ai.TotalSalePrice.DataContext = new ObservableCollection<SaleProduct>();

                    ai.TotalSalePrice.DataContext = ai.SProd;
                }
            
                else
                {
                    ai.obs.Add(new ProductInvocie
                    {
                        Product = (Product)prodName.SelectedItem,
                        Count = Convert.ToInt32(Count.Text),
                        ReceiptInvoice = ai.res
                    });

                    ai.TotalPrice.DataContext = new ObservableCollection<ProductInvocie>();

                    ai.TotalPrice.DataContext = ai.obs;
                }
                this.Close();
            }
            else
            {
                MessageBox.Show("Заполните все поля");
            }
            
        }

        private void Count_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex r = new Regex(@"^[1-9]{1}[0-9]{0,}$");
            if(!r.IsMatch(Count.Text + e.Text))
            {
                e.Handled = true;
            }
        }
    }
}
