﻿using System.Windows;
using System.Windows.Navigation;

namespace ProductionPractice
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : NavigationWindow
    {
        public static ProductionPracticeEntities DB = new ProductionPracticeEntities();
        public static User userValue;
        public MainWindow()
        {
            InitializeComponent();
            MnWindow.NavigationService.Navigate(new Authorization());
        }
    }
}
