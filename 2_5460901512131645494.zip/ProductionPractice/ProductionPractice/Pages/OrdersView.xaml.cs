﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProductionPractice
{
    /// <summary>
    /// Логика взаимодействия для OrdersView.xaml
    /// </summary>
    public partial class OrdersView : Page
    {
        public OrdersView()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new AddInvoice(false, 1));
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (MainWindow.userValue.RoleId == 3)
            {
                ListSaleClient.ItemsSource = MainWindow.DB.Sale.Where(x => x.ClientId == MainWindow.userValue.Id).ToList().OrderByDescending(x => x.Date);
            }
            else
            {
                ListSaleClient.ItemsSource = MainWindow.DB.Sale.Where(x => x.UserAdmin == null || x.AdministratorId == MainWindow.userValue.Id).ToList().OrderByDescending(x => x.Date);
                AddButton.Visibility = Visibility.Hidden;
            }
        }

        private void ListSaleClient_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (ListSaleClient.SelectedItem != null)
            {
                if (MainWindow.userValue.RoleId == 1)
                {
                    this.NavigationService.Navigate(new AddInvoice(ListSaleClient.SelectedItem as Sale, true));
                }
                else
                {
                    this.NavigationService.Navigate(new AddInvoice(ListSaleClient.SelectedItem as Sale));
                }
            }
        }

        private void GoBack_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.GoBack();
        }
    }
}
