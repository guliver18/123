﻿using ProductionPractice.Properties;
using System;
using System.Linq;
using System.Net.NetworkInformation;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace ProductionPractice
{
    /// <summary>
    /// Логика взаимодействия для Authorization.xaml
    /// </summary>
    public partial class Authorization : Page
    {
        public Authorization()
        {
            InitializeComponent();
            if (!string.IsNullOrEmpty(Properties.Settings.Default.login))
            {
                Logn.Text = Properties.Settings.Default.login.Trim();
            }
        }
        int countWar = 0;

        private void Enter_Click(object sender, RoutedEventArgs e)
        {
            if (Logn.Text != "" && Pass.Password != "")
            {
                User user = MainWindow.DB.User.Where(u => u.Login == Logn.Text).ToList().FirstOrDefault();
                if (user != null)
                {
                    
                    if ((DateTime.Now - Properties.Settings.Default.dateTm).TotalSeconds > 60)
                    {
                        Settings.Default.dateTm = DateTime.MinValue;
                        Properties.Settings.Default.Save();
                        if (user.Password == Pass.Password)
                        {
                            MainWindow.userValue = user;
                            DataContext = user;
                            if (user.RoleId == 1)
                            {
                                this.NavigationService.Navigate(new Products(user.Id));
                            }
                            else if(user.RoleId == 2)
                            {
                                this.NavigationService.Navigate(new MainKlad());
                            }
                            else
                            {
                                this.NavigationService.Navigate(new Products(user.Id, false));
                            }

                            if (SaveMe.IsChecked == true)
                            {
                                Properties.Settings.Default.login = user.Login;
                                Properties.Settings.Default.Save();
                            }
                        }
                        else
                        {
                            countWar ++;
                            MessageBox.Show("Пароль не правильный!");
                            if (countWar == 3)
                            {
                                MessageBox.Show("Превышен лимит попыток ввода пароля");
                                Properties.Settings.Default.dateTm = System.DateTime.Now;
                                Properties.Settings.Default.Save();
                                countWar = 0;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Превышен лимит попыток ввода пароля, подождите");
                    }
                }
                else MessageBox.Show("Логин или пароль не правильный!");
            }
            else MessageBox.Show("Заполните все поля!");
        }

        private void Path_Click(object sender, MouseButtonEventArgs e)
        {
            if (PassText.Visibility == Visibility.Visible)
            {
                Pass.Password = PassText.Text;
                PassText.Visibility = Visibility.Hidden;
                Pass.Visibility = Visibility.Visible;
            }
            else
            {
                PassText.Text = Pass.Password;
                PassText.Visibility = Visibility.Visible;
                Pass.Visibility = Visibility.Hidden;
            }
        }

        private void Logn_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Logn.Text == "Логин" && PassText.Text == "Пароль" || PassText.Text == "")
                Logn.Text = "";
            else if (Logn.Text == "Логин")
            {
                Logn.Text = "";
                PassText.Visibility = Visibility.Hidden;
                Pass.Visibility = Visibility.Visible;
            }
        }

        private void Logn_LostFocus(object sender, RoutedEventArgs e)
        {
            if (Logn.Text == "")
                Logn.Text = "Логин";
        }

        private void PassText_GotFocus(object sender, RoutedEventArgs e)
        {
            Pass.Focus();
            PassText.Visibility = Visibility.Hidden;
            Pass.Visibility = Visibility.Visible;
            Pass.Focus();
        }

        private void Pass_LostFocus(object sender, RoutedEventArgs e)
        {
            if (Pass.Password == "")
            {
                Pass.Visibility = Visibility.Hidden;
                PassText.Visibility = Visibility.Visible;
                PassText.Text = "Пароль";
            }
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Registration());
        }
    }
}
