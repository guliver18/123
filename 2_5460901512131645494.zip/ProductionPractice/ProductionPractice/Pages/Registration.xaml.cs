﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProductionPractice
{
    /// <summary>
    /// Логика взаимодействия для Registration.xaml
    /// </summary>
    public partial class Registration : Page
    {
        public Registration()
        {
            InitializeComponent();
        }
        private void Path_Click(object sender, MouseButtonEventArgs e)
        {
            if (PassText.Visibility == Visibility.Visible)
            {
                Pass.Password = PassText.Text;
                PassText.Visibility = Visibility.Hidden;
                Pass.Visibility = Visibility.Visible;
            }
            else
            {
                PassText.Text = Pass.Password;
                PassText.Visibility = Visibility.Visible;
                Pass.Visibility = Visibility.Hidden;
            }
        }

        private void Logn_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Login.Text == "Логин" && PassText.Text == "Пароль" || PassText.Text == "")
                Login.Text = "";
            else if (Login.Text == "Логин")
            {
                Login.Text = "";
                PassText.Visibility = Visibility.Hidden;
                Pass.Visibility = Visibility.Visible;
            }
        }

        private void Logn_LostFocus(object sender, RoutedEventArgs e)
        {
            if (Login.Text == "")
                Login.Text = "Логин";
        }

        private void PassText_GotFocus(object sender, RoutedEventArgs e)
        {
            Pass.Focus();
            PassText.Visibility = Visibility.Hidden;
            Pass.Visibility = Visibility.Visible;
            Pass.Focus();
        }

        private void Pass_LostFocus(object sender, RoutedEventArgs e)
        {
            if (Pass.Password == "")
            {
                Pass.Visibility = Visibility.Hidden;
                PassText.Visibility = Visibility.Visible;
                PassText.Text = "Пароль";
            }
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            WarLogin.Visibility = Visibility.Hidden;
            WarPassord.Visibility = Visibility.Hidden;
            if (Login.Text !="" && Login.Text != "Логин" 
                && Pass.Password != "")
            {
                Regex myReg = new Regex(@"^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[*.!@$%^&]).{6,16}$");
                if (myReg.IsMatch(Pass.Password))
                {
                    
                    if(MainWindow.DB.User.Where(x=>x.Login == Login.Text).ToList().Count == 0)
                    {
                        MainWindow.userValue = new User
                        {
                            Login = Login.Text,
                            Password = Pass.Password,
                            RoleId = 3
                        };

                        MainWindow.DB.User.Add(MainWindow.userValue);
                        MainWindow.DB.SaveChanges();
                        MessageBox.Show("Вы успешно зарегистрировались");
                        NavigationService.GoBack();
                    }
                    else
                    {

                        WarLogin.Visibility = Visibility.Visible;
                    }
                }
                else WarPassord.Visibility = Visibility.Visible;
            }
        }
    }
}
