﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace ProductionPractice
{
    /// <summary>
    /// Логика взаимодействия для AddInvoice.xaml
    /// </summary> 
    public partial class AddInvoice : Page
    {
        public bool isSale = false;
        public ObservableCollection<ProductInvocie> obs = new ObservableCollection<ProductInvocie>();
        public ReceiptInvoice res = new ReceiptInvoice();
        public Sale sale = new Sale();
        public Sale SaleOld;
        public ObservableCollection<SaleProduct> SProd = new ObservableCollection<SaleProduct>();

        public AddInvoice()
        {
            InitializeComponent();
        }

        public AddInvoice(bool info):this() // приходная накладная
        {
            rr.ItemsSource = MainWindow.DB.Product.ToList();
            ListProd.ItemsSource = obs;
            TotalPrice.DataContext = obs;
        }
        public AddInvoice(bool info,int z) : this() // создаём заказ
        {
            isSale = true;
            Status.IsEnabled = false;
            rrSale.ItemsSource = MainWindow.DB.Product.ToList();
            Status.SelectedIndex = 0;
            ListSale.ItemsSource = SProd;
            TotalSalePrice.DataContext = SProd;
            SaleProd.Visibility = Visibility.Visible;
            ProdInvoice.Visibility = Visibility.Hidden;
        }

        public AddInvoice(Sale saleOld) : this() // заходим в созданный
        {
            SaleOld = saleOld;
            isSale = true;
            
            DateCreate.SelectedDate = SaleOld.Date;
            DateCreate.IsEnabled = false;
            Status.IsEnabled = false;
            rrSale.ItemsSource = MainWindow.DB.Product.ToList();
            Status.SelectedIndex = (int)saleOld.Status;
            foreach (var item in SaleOld.SaleProduct)
            {
                SProd.Add(item);
            }
            ListSale.ItemsSource = SProd;
            TotalSalePrice.DataContext = SProd;
            SaleProd.Visibility = Visibility.Visible;
            ProdInvoice.Visibility = Visibility.Hidden;
            if(SaleOld.Status != 0)
            {
                ListSale.IsEnabled = false;
                SaveButton.Visibility = Visibility.Hidden;
                EditButton.Visibility = Visibility.Hidden;
            }
        }

        public AddInvoice(Sale saleOld, bool info) : this(saleOld) // заходим за админа
        {

            ListSale.IsEnabled = false;
         
            EditButton.Visibility = Visibility.Hidden;
            if (MainWindow.userValue.RoleId == 1)
            {
                if (saleOld.UserAdmin == null)
                {
                    AdminButton.Visibility = Visibility.Visible;
                    BackButton.Visibility = Visibility.Hidden;
                    SaveButton.Visibility = Visibility.Hidden;
                    SaleOld.Status = 1;
                   
                    SaleOld.UserAdmin = MainWindow.userValue;
                    MainWindow.DB.SaveChanges();
                }
                else
                {
                    Status.IsEnabled = true;
                    SaveButton.Visibility = Visibility.Visible;
                }
            }
            if(saleOld.Status == 5)
            {
                Status.IsEnabled = false;
            }

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AddProduct ad = new AddProduct(this);
            ad.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

                if (isSale)
                {
                    SProd.Remove((SaleProduct)ListSale.SelectedItem);
                }
                else
                {
                    obs.Remove((ProductInvocie)ListProd.SelectedItem);
                }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if(MainWindow.userValue.Role.Id == 1)
            {
                MessageBox.Show("1");
                SaleOld.Status = Status.SelectedIndex;
                if (SaleOld.Status == 5)
                {
                    MessageBox.Show("");
                    foreach (var item in SaleOld.SaleProduct)
                    {
                        Product prod = MainWindow.DB.Product.Where(x => x.Id == item.ProductId).FirstOrDefault();
                        prod.Count -= item.Count;
                    }
                }
                MainWindow.DB.SaveChanges();
                NavigationService.GoBack();
                
                return;
            }

            if (isSale)
            {
                if (SaleOld == null)
                {
                    sale.Date = DateTime.Now;
                    sale.UserClient = MainWindow.userValue;
                    foreach (var item in SProd)
                    {
                        sale.SaleProduct.Add(item);
                    }
                    sale.Status = Status.SelectedIndex;
                    MainWindow.DB.Sale.Add(sale);
                }
                else
                {
                    List<SaleProduct> sp = SaleOld.SaleProduct.ToList();
                    foreach (var item in sp)
                    {
                        SaleOld.SaleProduct.Remove(item);
                    };
                    SaleOld.SaleProduct = SProd;
                }
            }
            else
            {
                res.Date = DateTime.Now;
                foreach (var item in obs)
                {
                    res.ProductInvocie.Add(item);
                }
                MainWindow.DB.ReceiptInvoice.Add(res);
                foreach (var item in res.ProductInvocie)
                {
                    Product prod = MainWindow.DB.Product.Where(x => x.Id == item.ProductId).FirstOrDefault();
                    prod.Count += item.Count;
                }
            }
            MainWindow.DB.SaveChanges();
            this.NavigationService.GoBack();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.GoBack();

        }

        private void Reject_Click(object sender, RoutedEventArgs e)
        {
            SaleOld.Status = 2;
            Status.SelectedIndex = 2;
            AdminButton.Visibility = Visibility.Hidden;
            SaveButton.Visibility = Visibility.Visible;
            MainWindow.DB.SaveChanges();

        }

        private void Accept_Click(object sender, RoutedEventArgs e)
        {

            Status.IsEnabled = true;
            Status.SelectedIndex = 3;
            AdminButton.Visibility = Visibility.Hidden;
            SaveButton.Visibility = Visibility.Visible;
            MainWindow.DB.SaveChanges();
        }
    }
}
