﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace ProductionPractice
{
    /// <summary>
    /// Логика взаимодействия для AddProduct.xaml
    /// </summary>
    public partial class AddEditProduct : Page
    {
        Product newProduct;
        string photoProduct;
        int userId2;
        List<CheckBox> ch = new List<CheckBox>();
        public AddEditProduct(Product product, int userId)
        {
            InitializeComponent();
            newProduct = null;
            newProduct = product;
            this.userId2 = userId;
            DataContext = newProduct;
            TypeUnitBox.ItemsSource = MainWindow.DB.TypeUnit.ToList();
            List<Country> co = new List<Country>();
            if(newProduct != null) co = newProduct.ProductCountry.Select(x => x.Country).ToList();
            foreach (var item in MainWindow.DB.Country.ToList())
            {
                CheckBox check = new CheckBox
                {
                    DataContext = item,
                    Foreground = (Brush)(new BrushConverter().ConvertFrom(item.Color)),
                    Content = new TextBlock { Text = item.Name }
                };
                if(co.Contains(item))
                check.IsChecked = true;
                ch.Add(check);
            }
            CountryA.ItemsSource = ch;
            AddEdit();
        }

        private void AddEdit()
        {
            if (newProduct != null)
            {
                AddEd.Text = "Редактирование продукта";
                IdProduct.Visibility = Visibility.Visible;
                IdentProduct.Visibility = Visibility.Visible;
                NameProduct.Text = newProduct.Name;
                Image img = new Image();
                byte[] imageData = newProduct.Photo;
                MemoryStream stream = new MemoryStream(imageData);
                img.Source = BitmapFrame.Create(stream, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
                ProductPhoto.Source = img.Source;
                CommentProduct.Text = newProduct.Comment;
                dataAdd.Visibility = Visibility.Visible;
                dataAdd.Text = newProduct.DataAdd.ToString("dd-MM-yyyy");
                TypeUnitBox.SelectedItem = newProduct.TypeUnit.Name;
               
                

            }
            else if (newProduct == null)
            {
                IdProduct.Visibility = Visibility.Hidden;
                IdentProduct.Visibility = Visibility.Hidden;
                AddEd.Text = "Добавление продукта";
                NameProduct.Text = "Название";
                ProductPhotoName.Text = "Картинка продукта";
                CommentProduct.Text = "Комментарий";
                dataAdd.Visibility = Visibility.Visible;
                dataAdd.SelectedDate = DateTime.Now;
                TypeUnitBox.SelectedItem = "Единица измерения";
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
           
            if (CommentProduct.Text != "" && CommentProduct.Text != "Комментарий" && TypeUnitBox.SelectedItem != null
                && NameProduct.Text != "" && NameProduct.Text != "Название" && ch.Where(x=>x.IsChecked ==true).ToList().Count > 0)
            {
                if (newProduct == null)
                {
                    Product prod = new Product();
                    prod.Name = NameProduct.Text;
                    prod.Photo = File.ReadAllBytes(photoProduct);
                    prod.Comment = CommentProduct.Text;
                    prod.DataAdd = DateTime.Now;
                    prod.TypeUnitId = TypeUnitBox.SelectedIndex;
                    prod.UserId = userId2;
                    foreach (var item in ch)
                    {
                        if ((bool)item.IsChecked)
                        {
                            prod.ProductCountry.Add(new ProductCountry
                            {
                                CountruId = ((Country)item.DataContext).Id
                            }) ;
                        }
                    }
                    MainWindow.DB.Product.Add(prod);
                }
                else
                {
                    newProduct.Name = NameProduct.Text;
                    if (photoProduct != null)
                        newProduct.Photo = File.ReadAllBytes(photoProduct);
                    newProduct.Comment = CommentProduct.Text;
                    newProduct.DataAdd = Convert.ToDateTime(dataAdd.Text);
                    newProduct.TypeUnitId = (TypeUnitBox.SelectedItem as TypeUnit).Id;
                    newProduct.UserId = userId2;
                    MainWindow.DB.ProductCountry.RemoveRange(newProduct.ProductCountry.ToList());
                    newProduct.ProductCountry.Clear();
                    foreach (var item in ch)
                    {
                        if ((bool)item.IsChecked)
                        {
                            newProduct.ProductCountry.Add(new ProductCountry
                            {
                                CountruId = ((Country)item.DataContext).Id
                            });
                        }
                    }
                }
                MainWindow.DB.SaveChanges();
                MessageBox.Show("Информация успешно сохранена!");
                NavigationService.GoBack();
            }
            else
            {
                MessageBox.Show("Заполните все поля");
            }
        

            
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void AddImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Выберите картинку";
            openFileDialog.Filter = "Image file (*.png;*.jpg)|*.png;*.jpeg";
            if(openFileDialog.ShowDialog() == true)
            {
                ProductPhoto.Source = new BitmapImage(new Uri(openFileDialog.FileName));
            }
            photoProduct = openFileDialog.FileName;
            ProductPhotoName.Text = photoProduct;
            ProductPhotoName.Opacity = 1;
        }

        private void NameProduct_GotFocus(object sender, RoutedEventArgs e)
        {
            if (NameProduct.Text == "Название")
                NameProduct.Text = "";
        }

        private void NameProduct_LostFocus(object sender, RoutedEventArgs e)
        {
            if (NameProduct.Text == "")
                NameProduct.Text = "Название";
        }

        private void CommentProduct_GotFocus(object sender, RoutedEventArgs e)
        {
            if (CommentProduct.Text == "Комментарий")
                CommentProduct.Text = "";
        }

        private void CommentProduct_LostFocus(object sender, RoutedEventArgs e)
        {
            if (CommentProduct.Text == "")
                CommentProduct.Text = "Комментарий";
        }

        private void dataAdd_GotFocus(object sender, RoutedEventArgs e)
        {
            if (dataAdd.Text == "Дата добавления")
                dataAdd.Text = "";
        }

        private void dataAdd_LostFocus(object sender, RoutedEventArgs e)
        {
            if (dataAdd.Text == "")
                dataAdd.Text = "Дата добавления";
        }

        private void typeUnit_GotFocus(object sender, RoutedEventArgs e)
        {
            if (TypeUnitBox.Text == "Единица измерения")
                TypeUnitBox.Text = "";
        }

        private void typeUnit_LostFocus(object sender, RoutedEventArgs e)
        {
            if (TypeUnitBox.Text == "")
                TypeUnitBox.Text = "Единица измерения";
        }

        private void NameProduct_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            string Symbol = e.Text.ToString();

            if (!Regex.Match(Symbol, @"[а-яА-Я]|[a-zA-Z]|[-]|[ ]").Success)
            {
                e.Handled = true;
            }
        }

        private void CommentProduct_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            string Symbol = e.Text.ToString();

            if (!Regex.Match(Symbol, @"[а-яА-Я]|[a-zA-Z]|[-]|[ ]").Success)
            {
                e.Handled = true;
            }
        }

    }
}
