﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Navigation;

namespace ProductionPractice
{
    /// <summary>
    /// Логика взаимодействия для Products.xaml
    /// </summary>
    public partial class Products : Page
    {
        int userId1;
        List<Product> ProductList;
        bool isClient;

        int SortInterval = 0;
        int CurrentPosition = 0;
        List<Product> productValueList;
        public Products(int userId)
        {
            InitializeComponent();
            this.userId1 = userId;
            TypeUnitBox.ItemsSource = MainWindow.DB.TypeUnit.ToList();
        }

        public Products(int userId, bool info):this(userId)
        {
            isClient = true;
            AddButton.Visibility = Visibility.Hidden;
            DeletedClick.Visibility = Visibility.Hidden;
        }

        private void Search_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Search.Text == "Название, комментарий...")
            {
                Search.Text = "";
                Search.Foreground = Brushes.Black;
            }
        }

        private void Search_LostFocus(object sender, RoutedEventArgs e)
        {
            if (Search.Text == "")
                Search.Text = "Название, комментарий...";
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditProduct(null, userId1));
        }

        private void ListViewItem_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
           if(!isClient)
            NavigationService.Navigate(new AddEditProduct((sender as ListViewItem).DataContext as Product, userId1));
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            var deleteProduct = Product.SelectedItems.Cast<Product>().ToList();
            if (Product.SelectedItem as Product != null)
            {
                if (MessageBox.Show("Вы точно хотите удалить запись?", "Внимание",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    List<ProductCountry> pc = new List<ProductCountry>();
                    foreach (Product item in deleteProduct)
                    {
                        MainWindow.DB.ProductCountry.RemoveRange(item.ProductCountry);
                    }
                    MainWindow.DB.Product.RemoveRange(deleteProduct);
                    try
                    {
                        MainWindow.DB.SaveChanges();
                        MainWindow.DB.ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                        ProductList = MainWindow.DB.Product.OrderBy(p => p.Name).OrderBy(p => p.DataAdd).ToList();
                        Product.ItemsSource = ProductList;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString());
                    }
                }
            }
            else MessageBox.Show("Выберите элемент для удаления!");
        }

        private void AllInfo_Click(object sender, RoutedEventArgs e)
        {
            Product.ItemsSource = ProductList;
            TypeUnitBox.SelectedItem = null;
            CurrentMonth.IsChecked = false;
            CountList.Content = $"{ProductList.Count()} из {ProductList.Count()}";
            Search.Text = "Название, комментарий...";
        }

        private void FilterSearch()
        {
            var itemsInfo = ProductList;
            
            if (Search.Text != "Название, комментарий..." && Search.Text != "")
            {
                itemsInfo = itemsInfo.Where(i => i.Name.ToLower().IndexOf(Search.Text.ToLower()) != -1 || 
                i.Comment.ToLower().IndexOf(Search.Text.ToLower()) != -1).ToList();
            }
            if (CurrentMonth.IsChecked == true)
                itemsInfo = itemsInfo.Where(p => p.DataAdd.Month == DateTime.Now.Month).OrderBy(p => p.Name).OrderBy(p => p.DataAdd).ToList();
            if (TypeUnitBox.SelectedItem != null)
                itemsInfo = itemsInfo.Where(p => p.TypeUnitId == (TypeUnitBox.SelectedItem as TypeUnit).Id).ToList();
            productValueList = itemsInfo;
            if (CountRecord.SelectedIndex == 0)
            {
                SortInterval = 0;
                CurrentPosition = 0;
                back.Visibility = Visibility.Hidden;
                move.Visibility = Visibility.Hidden;
            }
            else if (CountRecord.SelectedIndex == 1)
            {
                itemsInfo = itemsInfo.OrderBy(f => f.Id).Skip(0).Take(10).ToList();
                SortInterval = 10;
                CurrentPosition = 0;
                back.Visibility = Visibility.Hidden;
                move.Visibility = Visibility.Visible;
            }
            else if (CountRecord.SelectedIndex == 2)
            {
                itemsInfo = itemsInfo.OrderBy(f => f.Id).Skip(0).Take(50).ToList();
                SortInterval = 50;
                CurrentPosition = 0;
                back.Visibility = Visibility.Hidden;
                move.Visibility = Visibility.Visible;
            }
            else
            {
                itemsInfo = itemsInfo.OrderBy(f => f.Id).Skip(0).Take(200).ToList();
                SortInterval = 200;
                CurrentPosition = 0;
                back.Visibility = Visibility.Hidden;
                move.Visibility = Visibility.Visible;
            }
            if (itemsInfo != null)
                Product.ItemsSource = itemsInfo;
            CountList.Content = $"{itemsInfo.Count()} из {ProductList.Count()}";
        }


        private void Search_Click(object sender, RoutedEventArgs e)
        {
            FilterSearch();
        }

        private void InfoInMonth_Click(object sender, RoutedEventArgs e)
        {
            FilterSearch();
        }

        private void TypeUnitBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            FilterSearch();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            ProductList = MainWindow.DB.Product.OrderBy(p => p.Name).OrderBy(p => p.DataAdd).ToList();
            MainWindow.DB.ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
            Product.ItemsSource = ProductList;
        }

        private void Search_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            FilterSearch();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            CurrentPosition -= SortInterval;
            Product.ItemsSource = productValueList.OrderBy(f => f.Id).Skip(CurrentPosition).Take(SortInterval).ToList();
           
            if (CurrentPosition + SortInterval  == productValueList.Count)
            {
                back.Visibility = Visibility.Hidden;
                move.Visibility = Visibility.Hidden;
            }
            else if (CurrentPosition + SortInterval >= productValueList.Count)
            {
                back.Visibility = Visibility.Visible;
                move.Visibility = Visibility.Hidden;
            }
            else
            {
                back.Visibility = Visibility.Visible;
                move.Visibility = Visibility.Visible;
            }
            CountList.Content = $"{((List<Product>)Product.ItemsSource).Count()} из {ProductList.Count()}";
        }

        private void Move_Click(object sender, RoutedEventArgs e)
        {
            CurrentPosition += SortInterval;
            Product.ItemsSource = productValueList.OrderBy(f => f.Id).Skip(CurrentPosition).Take(SortInterval).ToList();
            
            if (CurrentPosition + SortInterval >= productValueList.Count)
            {
                back.Visibility = Visibility.Visible;
                move.Visibility = Visibility.Hidden;
            }

            else
            {
                back.Visibility = Visibility.Visible;
                move.Visibility = Visibility.Visible;
            }
            CountList.Content = $"{((List<Product>)Product.ItemsSource).Count()} из {ProductList.Count()}";
        }

        bool sortName = true;
        bool sortDate = true;

        private void Name_Sort(object sender, MouseButtonEventArgs e)
        {
           if(sortName)
            Product.ItemsSource = ((List<Product>)Product.ItemsSource).OrderBy(x=>x.Name).ToList();
           else Product.ItemsSource = ((List<Product>)Product.ItemsSource).OrderByDescending(x => x.Name).ToList();

        }
        
        private void Date_Sort(object sender, MouseButtonEventArgs e)
        {
            if (sortDate)
                Product.ItemsSource = ((List<Product>)Product.ItemsSource).OrderBy(x => x.DataAdd).ToList();
            else Product.ItemsSource = ((List<Product>)Product.ItemsSource).OrderByDescending(x => x.DataAdd).ToList();
        }

        private void Order_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new OrdersView());
        }
    }
}
